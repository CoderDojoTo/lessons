CoderDojo Sushi, My First Website Version 1.0 11 May 2014

GENERAL NOTES
-------------

Examples assume a Windows environment.

1) Copy the about-me.html file and the images and css folders to the learner's machine before using the cards

2) You can also copy the worksheets folder. This contains the PDF and Open Document format Sushi Cards.

3) It's a good idea to ensure that file extensions are visible in Windows Explorer on the target computer.

4) Get the learner started by opening about-me.html in a browser and also in Notepad and then arranging them side-by-side. Then give the learner Card 1.

AUTHOR
------

Clyde Hatter

clyde.hatter@newchapter.ie

LICENSE
-------

This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.



